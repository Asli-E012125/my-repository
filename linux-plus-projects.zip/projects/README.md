# Linux Projects

List of projects within Linux workshop as follows;

- [Project 101-Linux Advanced Project : Backup, User and Group Management, String Manipulation with Linux Commands and Bash Scripting](./Project-101/README.md)